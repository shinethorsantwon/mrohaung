module.exports=[44856,(e,o,d)=>{}];

//# sourceMappingURL=web__next-internal_server_app_api_images_%5Bid%5D_route_actions_8283c02f.js.map