module.exports=[30280,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_login_page_actions_1f36a634.js.map