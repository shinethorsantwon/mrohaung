module.exports=[79694,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_profile_%5Bid%5D_page_actions_2c2eb46a.js.map