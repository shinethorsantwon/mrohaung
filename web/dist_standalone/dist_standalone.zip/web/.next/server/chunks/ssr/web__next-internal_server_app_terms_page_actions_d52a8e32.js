module.exports=[31599,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_terms_page_actions_d52a8e32.js.map