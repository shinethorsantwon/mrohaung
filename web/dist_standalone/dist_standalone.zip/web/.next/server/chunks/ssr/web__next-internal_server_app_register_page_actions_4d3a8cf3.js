module.exports=[41359,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_register_page_actions_4d3a8cf3.js.map