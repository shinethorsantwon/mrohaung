module.exports=[5197,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app__not-found_page_actions_9eaa9845.js.map