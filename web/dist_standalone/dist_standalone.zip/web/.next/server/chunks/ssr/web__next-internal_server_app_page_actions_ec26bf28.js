module.exports=[80461,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_page_actions_ec26bf28.js.map