module.exports=[80236,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_settings_page_actions_49df1891.js.map