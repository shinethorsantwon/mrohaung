globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/343408704ec53533.js",
    "static/chunks/1627bf2f54f2038d.js",
    "static/chunks/e92d492086a8c1b6.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/turbopack-1dcd249fd1dec0d2.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];