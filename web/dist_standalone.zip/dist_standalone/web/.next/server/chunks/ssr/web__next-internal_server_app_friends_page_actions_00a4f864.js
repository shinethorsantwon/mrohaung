module.exports=[57398,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_friends_page_actions_00a4f864.js.map