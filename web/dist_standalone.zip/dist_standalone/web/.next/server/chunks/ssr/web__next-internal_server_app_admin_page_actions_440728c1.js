module.exports=[11891,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_admin_page_actions_440728c1.js.map