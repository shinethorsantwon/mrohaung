module.exports=[7161,(a,b,c)=>{}];

//# sourceMappingURL=web__next-internal_server_app_messages_page_actions_0f6feb90.js.map