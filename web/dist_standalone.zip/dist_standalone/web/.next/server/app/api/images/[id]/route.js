var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/images/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__07b5d643._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/web__next-internal_server_app_api_images_[id]_route_actions_8283c02f.js")
R.m(86776)
module.exports=R.m(86776).exports
